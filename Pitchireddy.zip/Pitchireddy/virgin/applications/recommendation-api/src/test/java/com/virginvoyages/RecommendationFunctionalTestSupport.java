package com.virginvoyages;

import org.junit.Test;

public class RecommendationFunctionalTestSupport extends FunctionalTestSupport{
	
	@Test
    public void contextLoads() {
    }

}
