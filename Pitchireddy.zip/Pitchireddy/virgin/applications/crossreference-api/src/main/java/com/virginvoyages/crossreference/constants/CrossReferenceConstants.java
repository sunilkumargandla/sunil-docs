package com.virginvoyages.crossreference.constants;

public class CrossReferenceConstants {
	
	public static final int MAX_PAGE_SIZE = 20;

}
