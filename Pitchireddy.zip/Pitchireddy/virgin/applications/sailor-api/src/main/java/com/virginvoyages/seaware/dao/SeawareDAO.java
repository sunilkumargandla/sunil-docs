package com.virginvoyages.seaware.dao;

import com.virginvoyages.seaware.data.ClientData;

public interface SeawareDAO {
	
	public ClientData getSeawareClientData(String clientID);

}
